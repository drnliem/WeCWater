"use client";
import React, { useState } from "react";
import { useRouter } from 'next/navigation';
import { uploadFile } from "@/lib/storageservice";
import { createPost } from "@/services/forumservice";
import * as image from '../imageimport.jsx';
import Header from '@/components/header';

const Report = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [mediaFiles, setMediaFiles] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [type, settype] = useState("forum");
  const router = useRouter();
  const goToHome = () => {
    router.push('/home');
  };
  const handleFileChange = (e) => {
    setMediaFiles(Array.from(e.target.files));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Upload semua media file ke Firebase Storage
      const mediaUrls = [];
      for (const file of mediaFiles) {
        const url = await uploadFile(file, "posts");
        mediaUrls.push(url);
      }

      // Simpan data post ke Firestore
      await createPost({
        title,
        description,
        mediaUrls,
        createdAt: new Date(), // Bisa diganti serverTimestamp jika di postservice.js
        type
      });

      alert("Post berhasil dibuat!");
      // Reset form
      setTitle("");
      setDescription("");
      setMediaFiles([]);
      settype("forum");
    } catch (error) {
      alert("Gagal membuat post: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
      <>
           <Header />
           {/* konten lainnya */}
         </>

      {/* Title */}
      <h1 className="text-2xl font-bold text-gray-800 mt-6 mb-4">Tulis Forum</h1>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-white p-5 rounded-lg w-full max-w-xl box-border flex flex-col gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Judul</label>
          <input 
            type="text" 
            className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none" 
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Isi Forum</label>
          <textarea 
            className="w-full p-2 border border-gray-300 rounded-md text-gray-600 outline-none" 
            rows="4" 
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Upload Photo/Video</label>
          <input 
            type="file" 
            className="w-full p-2 border border-gray-300 text-gray-400 rounded-md" 
            multiple 
            onChange={handleFileChange}
            accept="image/*,video/*"
          />
        </div>

        <button 
          type="submit" 
          className="bg-cyan-500 text-white py-2 px-4 rounded-md hover:bg-cyan-600 disabled:bg-cyan-300"
          disabled={isSubmitting}
          
        >
          {isSubmitting ? "Submitting..." : "Submit Forum"}
        </button>
      </form>
    </div>
  );
};

export default Report;