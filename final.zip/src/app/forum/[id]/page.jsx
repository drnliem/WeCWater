'use client';
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { getPostById } from "@/services/postservice";
import * as image from '../../imageimport.jsx';
import Header from '@/components/header';

const Forum = () => {
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const data = await getPostById(id);
        setPost(data);
      } catch (err) {
        setError("Gagal memuat post.");
      }
    };
    fetchPost();
  }, [id]);

  if (error) return <p className="text-red-500">{error}</p>;
  if (!post) return <p>Loading...</p>;

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
          <>
           <Header />
           {/* konten lainnya */}
         </>

      {/* Konten utama */}
      <div className="p-5 w-full max-w-xl mx-auto py-2 bg-white rounded-md shadow-md">
        {/* User info */}
        <div className="flex items-center gap-3 mb-4 py-2 ">
          <img
            src={image.user_icon}
            alt="User Icon"
            className="w-12 h-12 rounded-full object-cover"
          />
          <span className="font-semibold text-gray-800">{post.username || "Anonymous"}</span>
          <span className="font-semibold text-gray-800"> || </span>
          <span className="font-semibold text-gray-800">{post.type}</span>
        </div>

        {/* Konten post tergantung jenis */}
        {post.type === "event" ? (
          <>
            <h1 className="text-2xl font-bold mb-4 text-gray-800">{post.Title} - {post.City}</h1>
            <p className="text-gray-600 mb-2"><strong>Location:</strong> {post.Lokasi}</p>
            <p className="mb-4 text-gray-600">{post.Maps}</p>
            <p className="mb-4 text-gray-600"><strong>Waktu Pelaksanaan:</strong> {post["Waktu Pelaksanaan"]}</p>

            {/* Media */}
            {post.mediaUrls && post.mediaUrls.length > 0 ? (
              post.mediaUrls.map((url, index) => (
                <div key={index} className="mb-2">
                  {url.endsWith(".mp4") ? (
                    <video controls className="w-full rounded-md">
                      <source src={url} type="video/mp4" />
                    </video>
                  ) : (
                    <img src={url} alt={`media-${index}`} className="w-full rounded-md" />
                  )}
                </div>
              ))
            ) : (
              <div className="text-gray-500">Tidak ada media.</div>
            )}
          </>
        ) : post.type === "post" ?(
          <>
            <h1 className="text-2xl font-bold mb-4 text-gray-800">{post.title}</h1>
            <p className="text-gray-600 mb-2"><strong>Location:</strong> {post.location}</p>
            <p className="mb-4 text-gray-600">{post.description}</p>
            
          </>
        ) : (
          <>
            <h1 className="text-2xl font-bold mb-4 text-gray-800">{post.title}</h1>
            
            <p className="mb-4 text-gray-600">{post.description}</p>
            
          </>
        )}
      </div>
    </div>
  );
};

export default Forum;
