'use client';
import { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { setUserProfile, isUsernameTaken } from '@/lib/setProfile';
import * as image from '../../imageimport.jsx';

export default function RegisterProfile() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const uid = searchParams.get('uid');
  const email = searchParams.get('email');

  const [mediaFiles, setMediaFiles] = useState([]);
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [useDefault, setUseDefault] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (useDefault && email) {
      const usernameFromEmail = email.split('@')[0];
      setUsername(usernameFromEmail);
      setBio('');
    }
  }, [useDefault, email]);

  const handleSave = async () => {
    setError(null);

    if (!uid) {
      setError("User tidak ditemukan.");
      return;
    }

    if (!username.trim()) {
      setError("Username wajib diisi.");
      return;
    }

    if (!useDefault) {
      const taken = await isUsernameTaken(username.toLowerCase());
      if (taken) {
        setError("Username sudah dipakai.");
        return;
      }
    }

    let photoURL = image.user_icon;

    if (mediaFiles.length > 0) {
      const file = mediaFiles[0];
      const fileName = `${uid}_${file.name}`;
      photoURL = `/images/${fileName}`;
      // Asumsinya file-nya sudah dipindahkan ke folder public/images secara manual atau lewat backend saat register
    }
    

    const data = {
      username: username.toLowerCase(),
      bio: useDefault ? '' : bio,
      photoURL,
      email,
    };

    try {
      await setUserProfile(uid, data);
      router.push('/home');
    } catch (err) {
      setError("Gagal menyimpan profil.");
    }
  };

  const handleFileChange = (e) => {
    setMediaFiles(Array.from(e.target.files));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gray-50">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h1 className="text-2xl font-bold mb-6 text-center text-gray-800">Set Profil</h1>

        <label className="inline-flex items-center mb-4 cursor-pointer text-gray-800">
          <input
            type="checkbox"
            checked={useDefault}
            onChange={(e) => setUseDefault(e.target.checked)}
            className="mr-2"
          />
          Gunakan Profil Default (username = email)
        </label>

        <label className="block mb-2 font-medium text-gray-700">Username</label>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          disabled={useDefault}
          className="w-full p-2 mb-4 border border-gray-300 rounded-md outline-none focus:ring-2 focus:ring-blue-400 text-gray-700"
          required
        />
        <label className="block mb-2 font-medium text-gray-700">Bio</label>
        {!useDefault && (
          <textarea
            placeholder="Bio (opsional)"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="w-full p-2 mb-4 border border-gray-300 rounded-md outline-none focus:ring-2 focus:ring-blue-400 text-gray-700"
          />
        )}
        <label className="block mb-2 font-medium text-gray-700">
          Profile Picture
        </label>
        <input
          type="file"
          className="w-full p-2 border border-gray-300 text-gray-400 rounded-md mb-4"
          multiple
          onChange={handleFileChange}
          accept="image/*,video/*"
        />
        <button
          onClick={handleSave}
          className="w-full bg-blue-600 text-white py-2 rounded-md font-semibold hover:bg-blue-700 transition-colors"
        >
          Simpan
        </button>

        {error && (
          <p className="mt-4 text-red-600 text-center font-semibold">{error}</p>
        )}
      </div>
    </div>
  );
}
