'use client';
import { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { setUserProfile, isUsernameTaken } from '@/lib/setProfile';

export default function RegisterProfile() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const uid = searchParams.get('uid');
  const email = searchParams.get('email');

  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [useDefault, setUseDefault] = useState(false);
  const [error, setError] = useState(null);

  // Jika checkbox useDefault aktif, isi username otomatis dari email dan kosongkan bio
  useEffect(() => {
    if (useDefault && email) {
      const usernameFromEmail = email.split('@')[0];
      setUsername(usernameFromEmail);
      setBio('');
    }
  }, [useDefault, email]);

  const handleSave = async () => {
    setError(null);

    if (!uid) {
      setError("User tidak ditemukan.");
      return;
    }

    if (!username.trim()) {
      setError("Username wajib diisi.");
      return;
    }

    if (!useDefault) {
      // cek username sudah dipakai atau belum
      const taken = await isUsernameTaken(username.toLowerCase());
      if (taken) {
        setError("Username sudah dipakai.");
        return;
      }
    }

    // Foto default dari folder public (misal /images/user.png)
    const defaultPhotoURL = '/images/user.png';

    const data = {
      username: username.toLowerCase(),
      bio: useDefault ? '' : bio,
      photoURL: defaultPhotoURL,
      email,
    };

    try {
      await setUserProfile(uid, data);
      router.push('/dashboard'); // sesuaikan page tujuan setelah set profil
    } catch (err) {
      setError("Gagal menyimpan profil.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gray-50">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h1 className="text-2xl font-bold mb-6 text-center">Set Profil</h1>

        <label className="inline-flex items-center mb-4 cursor-pointer">
          <input
            type="checkbox"
            checked={useDefault}
            onChange={(e) => setUseDefault(e.target.checked)}
            className="mr-2"
          />
          Gunakan Profil Default (username = email)
        </label>

        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          disabled={useDefault}
          className="w-full p-2 mb-4 border border-gray-300 rounded-md outline-none focus:ring-2 focus:ring-blue-400"
          required
        />

        {!useDefault && (
          <textarea
            placeholder="Bio (opsional)"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="w-full p-2 mb-4 border border-gray-300 rounded-md outline-none focus:ring-2 focus:ring-blue-400"
          />
        )}

        <button
          onClick={handleSave}
          className="w-full bg-blue-600 text-white py-2 rounded-md font-semibold hover:bg-blue-700 transition-colors"
        >
          Simpan
        </button>

        {error && (
          <p className="mt-4 text-red-600 text-center font-semibold">{error}</p>
        )}
      </div>
    </div>
  );
}
