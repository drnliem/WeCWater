"use client";
import React, { useState } from "react";
import { useRouter } from 'next/navigation';
import { uploadFile } from "@/lib/storageservice";
import { createPost } from "@/services/eventservice";
import * as image from '../imageimport.jsx';

const goals = () => {
  const [Title, setTitle] = useState("");
  const [Lokasi, setLokasi] = useState("");
  const [City, setCity] = useState("");
  const [WaktuPelaksanaan, setWaktuPelaksanaan] = useState("");
  const [Maps, setMaps] = useState("");
  const [GatherPoint, setGatherPoint] = useState("");
  const [Description, setDescription] = useState("");
  const [mediaFiles, setMediaFiles] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [type, settype] = useState("event");
  const router = useRouter();

  const goToHome = () => {
    router.push('/home');
  };

  const handleFileChange = (e) => {
    setMediaFiles(Array.from(e.target.files));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const mediaUrls = [];
      for (const file of mediaFiles) {
        const url = await uploadFile(file, "posts");
        mediaUrls.push(url);
      }

      await createPost({
        Title,
        Lokasi,
        City,
        ["Waktu Pelaksanaan"]: WaktuPelaksanaan,
        Maps,
        ["Gather Point"]: GatherPoint,
        Description,
        mediaUrls,
        createdAt: new Date(), 
        type
      });

      alert("Post berhasil dibuat!");
      setTitle(""); setLokasi(""); setCity(""); setWaktuPelaksanaan("");
      setMaps(""); setGatherPoint(""); setDescription(""); setMediaFiles([]); settype("event")
    } catch (error) {
      alert("Gagal membuat post: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      <header className="bg-blue-100 py-2 px-2 w-full max-w-xl box-border">
        <div className="flex justify-between items-center">
          <div className="flex items-center cursor-pointer px-2 py-2">
            <button>
              <img className="h-7 mr-5 cursor-pointer" alt="Menu" src={image.menu_icon} />
            </button>
            <img className="h-7 cursor-pointer" alt="User" src={image.user_icon} />
          </div>
          <div className="flex justify-end">
            <button>
              <img onClick={goToHome} className="h-20 ml-auto cursor-pointer" alt="WeCWater Logo" src={image.wecwater} />
            </button>
          </div>
        </div>
      </header>

      <h1 className="text-2xl font-bold text-gray-800 mt-6 mb-4">Make Event</h1>

      <form onSubmit={handleSubmit} className="bg-white p-5 rounded-lg w-full max-w-xl box-border flex flex-col gap-4">

        {/* Title */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
          <input type="text" className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none"
            value={Title} onChange={(e) => setTitle(e.target.value)} required />
        </div>

        {/* City */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Kota</label>
          <input type="text" className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none"
            value={City} onChange={(e) => setCity(e.target.value)} required />
        </div>

        {/* Lokasi */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Lokasi</label>
          <input type="text" className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none"
            value={Lokasi} onChange={(e) => setLokasi(e.target.value)} required />
        </div>

        
        {/* Waktu Pelaksanaan */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Waktu Pelaksanaan</label>
          <input type="text" className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none"
            value={WaktuPelaksanaan} onChange={(e) => setWaktuPelaksanaan(e.target.value)} required />
        </div>

        {/* Maps Link */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Google Maps Link</label>
          <input type="text" className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none"
            value={Maps} onChange={(e) => setMaps(e.target.value)} required />
        </div>

        {/* Gather Point */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Gather Point</label>
          <input type="text" className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none"
            value={GatherPoint} onChange={(e) => setGatherPoint(e.target.value)} required />
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea className="w-full p-2 border border-gray-300 rounded-md text-gray-600 outline-none" rows="4"
            value={Description} onChange={(e) => setDescription(e.target.value)} />
        </div>

        {/* Media Upload */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Upload Photo/Video</label>
          <input type="file" className="w-full p-2 border border-gray-300 text-gray-400 rounded-md"
            multiple onChange={handleFileChange} accept="image/*,video/*" />
        </div>

        {/* Submit */}
        <button type="submit"
          className="bg-cyan-500 text-white py-2 px-4 rounded-md hover:bg-cyan-600 disabled:bg-cyan-300"
          disabled={isSubmitting}>
          {isSubmitting ? "Submitting..." : "Submit"}
        </button>
      </form>
    </div>
  );
};

export default goals;
