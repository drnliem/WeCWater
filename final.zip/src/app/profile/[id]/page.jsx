'use client';
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { getPostById } from "@/services/postservice";
import * as image from '../../imageimport.jsx';

const Forum = () => {
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const data = await getPostById(id);
        setPost(data);
      } catch (err) {
        setError("Gagal memuat post.");
      }
    };
    fetchPost();
  }, [id]);

  if (error) return <p className="text-red-500">{error}</p>;
  if (!post) return <p>Loading...</p>;

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
            <header className="bg-blue-100 py-2 px-2 w-full max-w-xl box-border">
              <div className="flex justify-between items-center">
                <div className="flex items-center cursor-pointer px-2 py-2">
                  <button>
                    <img
                      className="h-7 mr-5 cursor-pointer"
                      alt="Menu"
                      src={image.menu_icon}
                    />
                  </button>
                  <img
                    className="h-7 cursor-pointer"
                    alt="WeCWater User"
                    src={image.user_icon}
                  />
                </div>
                <div className="flex justify-end">
                  <img
                    className="h-20 ml-auto"
                    alt="WeCWater Logo"
                    src={image.wecwater}
                  />
                </div>
              </div>
            </header>
      
    <div className="p-5 w-full max-w-xl mx-auto py-2 bg-white rounded-md shadow-md">
    {/* User info: image dan nama user berdampingan */}
      <div className="flex items-center gap-3 mb-4 py-2 ">
        <img
          src={image.user_icon}
          alt="User Icon"
          className="w-12 h-12 rounded-full object-cover"
        />
        <span className="font-semibold text-gray-800">{post.userName || "Anonymous"}</span>
      </div>

      {/* Title */}
      <h1 className="text-2xl font-bold mb-4 text-gray-800">{post.title}</h1>

      {/* Location */}
      <p className="text-gray-600 mb-2">
        <strong>Location:</strong> {post.location}
      </p>

      {/* Description */}
      <p className="mb-4 text-gray-600">{post.description}</p>

      {/* Media */}
      {post.mediaUrls && post.mediaUrls.length > 0 ? (
        post.mediaUrls.map((url, index) => (
          <div key={index} className="mb-2">
            {url.endsWith(".mp4") ? (
              <video controls className="w-full rounded-md">
                <source src={url} type="video/mp4" />
              </video>
            ) : (
              <img src={url} alt={`media-${index}`} className="w-full rounded-md" />
            )}
          </div>
        ))
      ) : (
        <div className="w-full h-full" />
      )}
    </div>
    </div>

    );
};

export default Forum;
