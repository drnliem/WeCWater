import { NextResponse } from 'next/server';
import multiparty from 'multiparty';
import fs from 'fs';
import path from 'path';

export const config = {
  api: {
    bodyParser: false,
  },
};

export async function POST(request) {
  const form = new multiparty.Form({
    uploadDir: path.join(process.cwd(), 'public/images'),
  });

  return new Promise((resolve, reject) => {
    form.parse(request, (err, fields, files) => {
      if (err) {
        reject(NextResponse.json({ error: err.message }, { status: 500 }));
        return;
      }

      const urls = [];
      if (files.file) {
        for (const file of files.file) {
          const fileName = path.basename(file.path);
          urls.push(`/images/${fileName}`);
        }
      }

      resolve(NextResponse.json({ urls }, { status: 200 }));
    });
  });
}
