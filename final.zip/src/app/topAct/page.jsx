"use client";
import React from "react";
import * as image from '../imageimport.jsx';

export const TopActivity = () => {
  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
      <header className="bg-blue-100 py-2 px-2 w-full max-w-xl box-border">
        <div className="flex justify-between items-center">
          <div className="flex items-center cursor-pointer px-2 py-2">
            <button>
              <img className="h-7 mr-5 cursor-pointer" alt="Menu" src={image.menu_icon} />
            </button>
            <img className="h-7 cursor-pointer" alt="User" src={image.user_icon} />
          </div>
          <div className="flex justify-end">
            <img className="h-20 ml-auto" alt="WeCWater Logo" src={image.wecwater} />
          </div>
        </div>
      </header>

      {/* Title */}
      <h1 className="text-2xl font-bold text-gray-800 mt-6 mb-4">Top Activity</h1>

      {/* Grid List */}
      <div className="grid grid-cols-1 gap-4 w-full max-w-xl">
        {[image.vector, image.vector2, image.vector3, image.vector4, image.vector5, image.vector6].map((vectorSrc, index) => (
          <div key={index} className="bg-white p-4 rounded-md flex items-center border border-gray-300 shadow-md">
            <img src={vectorSrc} alt={`Vector ${index}`} className="w-10 h-10 mr-4" />
            <div className="flex-1 h-10 bg-gray-100 rounded-md" />
            <img
              src={image[`location${index === 0 ? '' : index}`]} // location, location2, dst
              alt={`Location ${index}`}
              className="w-8 h-8 ml-4"
            />
          </div>
        ))}
      </div>

      {/* Button */}
      <div className="mt-6">
        <button className="bg-cyan-500 text-white py-2 px-6 rounded-lg hover:bg-cyan-600 transition">
          Back to Home
        </button>
      </div>
    </div>
  );
};
export default TopActivity;