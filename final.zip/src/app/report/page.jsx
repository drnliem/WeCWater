"use client";
import React, { useState } from "react";
import { useRouter } from 'next/navigation';
import { createPost } from "@/services/postservice";
import * as image from '../imageimport.jsx';
import Header from '@/components/header';

const Report = () => {
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [type, settype] = useState("report");
  const router = useRouter();

  const goToHome = () => {
    router.push('/home');
  };

  // Fungsi upload file ke API lokal /api/upload
  const uploadFilesToLocal = async (files) => {
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append("file", files[i]);
    }

    const res = await fetch("/api/upload", {
      method: "POST",
      body: formData,
    });

    if (!res.ok) {
      throw new Error("Gagal upload file");
    }

    const data = await res.json();
    return data.urls; // array URL hasil upload
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Upload semua media file ke API lokal
      let mediaUrls = [];
      if (selectedFiles.length > 0) {
        mediaUrls = await uploadFilesToLocal(selectedFiles);
      }

      // Simpan data post ke Firestore atau API lain
      await createPost({
        title,
        location,
        description,
        mediaUrls,
        createdAt: new Date(),
        type,
      });

      alert("Post berhasil dibuat!");

      // Reset form
      setTitle("");
      setLocation("");
      setDescription("");
      setSelectedFiles([]);
      settype("report");
    } catch (error) {
      alert("Gagal membuat post: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (e) => {
    setSelectedFiles(e.target.files);
  };

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
      <>
        <Header />
      </>

      {/* Title */}
      <h1 className="text-2xl font-bold text-gray-800 mt-6 mb-4">Report Location</h1>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-white p-5 rounded-lg w-full max-w-xl box-border flex flex-col gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
          <input 
            type="text" 
            className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none" 
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
          <input 
            type="text" 
            className="w-full p-2 border border-gray-300 text-gray-600 rounded-md outline-none" 
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
          <textarea 
            className="w-full p-2 border border-gray-300 rounded-md text-gray-600 outline-none" 
            rows="4" 
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Upload Photo/Video</label>
          <input 
            type="file" 
            className="w-full p-2 border border-gray-300 text-gray-400 rounded-md" 
            multiple 
            onChange={handleFileChange}
            accept="image/*,video/*"
          />
        </div>

        <button 
          type="submit" 
          className="bg-cyan-500 text-white py-2 px-4 rounded-md hover:bg-cyan-600 disabled:bg-cyan-300"
          disabled={isSubmitting}
        >
          {isSubmitting ? "Submitting..." : "Submit"}
        </button>
      </form>
    </div>
  );
};

export default Report;
