'use client';
import React, { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { wecwater, login_button } from '../imageimport.jsx';
import { login } from '@/lib/authservice';

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!email || !password) {
      setError('Email dan password harus diisi');
      setLoading(false);
      return;
    }

    try {
      const user = await login(email, password);
      console.log('User logged in:', user);
      // redirect ke halaman home setelah login sukses
      router.push('/home');
    } catch (err) {
      console.error('Login error:', err);
      setError('Login gagal: ' + (err.message || 'Terjadi kesalahan'));
    } finally {
      setLoading(false);
    }
  };

  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-blue-50 flex items-center justify-center px-4">
      <div className="absolute inset-x-0 top-0 flex justify-center">
          <Image
            src={wecwater}
            alt="Wecwater Logo"
            width={100}
            height={50}
            className="h-24 object-cover"
          />
        </div> 
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
          <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
            Login
          </h2>
          {error && (
          <p className="mb-4 text-red-600 text-center font-semibold">{error}</p>
          )}
          <label className="block mb-2 font-medium text-gray-700 py-2">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email/Username"
              required
              className="w-full px-4 py-2 border border-black rounded-md text-gray-600"
            />
          <label className="block mb-2 font-medium text-gray-700 py-2">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              required
              className="w-full px-4 py-2 border border-black rounded-md mb-4 text-gray-600"
            />

            <button
              type="submit"
              className="w-full px-4 py-2 bg-green-600 text-white rounded-full hover:bg-green-700 transition mt-10"
            >
              Submit
            </button>
            <div className="mt-4 flex justify-between text-sm text-gray-600">
              <a href="/forgetpass" className="text-blue-600 hover:underline">Forgot Password?</a>
              <a href="/register" className="text-blue-600 hover:underline">Sign Up</a>
            </div>
          </form>
    </div>
  );
}


