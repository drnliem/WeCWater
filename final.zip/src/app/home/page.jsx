'use client';
import React, {useState, useEffect, useRef} from 'react';
import { getPosts } from "@/services/postservice";
import { useRouter } from 'next/navigation';
import * as image from '../imageimport.jsx';

import SearchBar from '@/components/search';

export const Home = () => {
  const router = useRouter();
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef();


  const goToTop = () => {
    router.push('/topAct');
  };
  const goToForum = (id) => {
    router.push(`/forum/${id}`);
  };
  const goToMakeForum = (id) => {
    router.push(`/forum`);
  };
  const goToReport = () => {
    router.push('/report');
  };
  const goToProfile = () => {
    router.push('/profile');
  };
  const goToCommunity = () => {
    router.push('/community');
  };
  const goToDonateUS = () => {
    router.push('/donate-us');
  };
  const goToLoc = () => {
    router.push('/location');
  };
  const goToGoal = () => {
    router.push('/goals');
  };

  

  const [posts, setPosts] = useState([]);
  useEffect(() => {
    const fetchPosts = async () => {
      const data = await getPosts();
      setPosts(data);
    };

    fetchPosts();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
      <header className="bg-blue-100 py-2 px-2 w-full max-w-xl box-border">
        <div className="flex justify-between items-center">
          <div className="flex items-center cursor-pointer px-2 py-2">
            <div className="relative" ref={menuRef}>
              <button onClick={() => setShowMenu(!showMenu)}>
                <img
                  className="h-7 mr-5 cursor-pointer"
                  alt="Menu"
                  src={image.menu_icon}
                />
              </button>

              {showMenu && (
                <div className="absolute top-10 left-0 bg-white border rounded-lg shadow-lg z-50 w-40">
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      router.push('/home');
                    }}
                    className="block w-full px-4 py-2 text-left text-gray-800 hover:bg-gray-100">
                    Home
                  </button>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      router.push('/setting');
                    }}
                    className="block w-full px-4 py-2 text-left text-gray-800 hover:bg-gray-100">
                    Setting
                  </button>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      alert("Logout clicked"); // Ubah dengan fungsi logout aktual jika ada
                    }}
                    className="block w-full px-4 py-2 text-left text-gray-800 hover:bg-gray-100">
                    Logout
                  </button>
                </div>
              )}
            </div>
            <button onClick={goToProfile}>
            <img
              className="h-7 cursor-pointer"
              alt="WeCWater User"
              src={image.user_icon}
            />
            </button>  
          </div>
          <div className="flex justify-end">
            <img
              className="h-20 ml-auto"
              alt="WeCWater Logo"
              src={image.wecwater}
            />
          </div>
        </div>
      </header>

      {/* Search Bar */}
       
            <>
                 <SearchBar />
                 {/* konten lainnya */}
               </>

      {/* Forum Section */}
      <div className="bg-white p-5 rounded-lg w-full max-w-xl mt-5 box-border">
        <h2 className="text-xl font-bold text-gray-800 mb-4 text-left">
          Forum
        </h2>

        
        <div className=" flex justify-left py-4">
          <button
            onClick={goToMakeForum}
            className=" cursor-pointer bg-cyan-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow-md transition-colors "
          >
            + Create Forum
          </button>
        </div>
        <div className="flex flex-col gap-4 justify-center">
          {posts.length === 0 ? (
            <p className="text-center text-gray-500">Belum ada post.</p>
          ) : (
          posts.map((post) => (
          <button
          onClick={() => goToForum(post.id)}
            key={post.id}
            className="bg-cyan-100 p-5 rounded-md border-2 border-cyan-500 cursor-pointer hover:scale-105 hover:shadow-lg transition-transform"
          >
            <div className="flex items-center gap-3">
              <img
                className="h-10 w-8.5 object-cover"
                alt="Post Media"
                src={
                  post.type === 'event'
                    ? image.goals_icon
                    : post.type === 'forum'
                      ? image.user_icon
                      : image.report_icon  // kondisi ketiga (default)
                }
                
              />
              <div>
                <div className="text-left font-bold text-sm text-gray-800">{post.Title || post.title} </div>
                <div className="text-left text-xs text-gray-600">{post.Lokasi || post.author || 'anonymous forum'}</div>
              </div>
            </div>
          </button>
          ))
        )}
        </div>
         
      </div>

      {/* More Features Section */}
      <div className="bg-white p-4 rounded-lg w-full max-w-xl mt-5 box-border">
        <h2 className="text-lg font-bold mb-4 text-gray-800 text-center">
          More of Our Features
        </h2>
        <div  className="grid grid-cols-3 gap-2">
          <button onClick={goToGoal} className="bg-cyan-100 p-5 rounded-lg flex items-center border-2 border-cyan-500 cursor-pointer transition-transform transform hover:scale-105 hover:shadow-lg flex-col">
            <img
              className="h-7 mb-2 text-teal-700"
              alt="Goals"
              src={image.goals_icon}
            />
            <div className="text-sm text-black pt-2">Make Event</div>
          </button>
          <button onClick={goToLoc} className="bg-cyan-100 p-5 rounded-lg flex items-center border-2 border-cyan-500 cursor-pointer transition-transform transform hover:scale-105 hover:shadow-lg flex-col">
            <img
              className="h-7 mb-2 text-teal-700"
              alt="Location"
              src={image.location_icon}
            />
            <div className="text-sm text-black pt-2">Location</div>
          </button>
          <button onClick={goToTop} className="bg-cyan-100 p-5 rounded-lg flex items-center border-2 border-cyan-500 cursor-pointer transition-transform transform hover:scale-105 hover:shadow-lg flex-col">
            <img
              className="h-7 mb-2 text-teal-700"
              alt="Top Activity"
              src={image.top_icon}
            />
            <div className="text-sm text-black pt-2">Top Activity</div>
          </button>
          <button className="bg-cyan-100 p-5 rounded-lg flex items-center border-2 border-cyan-500 cursor-pointer transition-transform transform hover:scale-105 hover:shadow-lg flex-col">
            <img
              className="h-7 mb-2 text-teal-700"
              alt="Community"
              src={image.community_icon}
              onClick={goToCommunity}
            />
            <div className="text-sm text-black pt-2">Community</div>
          </button>
          <button
            onClick={goToReport}
            className="bg-cyan-100 p-5 rounded-lg flex items-center border-2 border-cyan-500 cursor-pointer transition-transform transform hover:scale-105 hover:shadow-lg flex-col"
          >
            <img
              className="h-7 mb-2 text-teal-700"
              alt="Report"
              src={image.report_icon}
            />
            <div className="text-sm text-black pt-2">Report Location</div>
          </button>

          <button 
            onClick={goToDonateUS}
            className="bg-cyan-100 p-5 rounded-lg flex items-center border-2 border-cyan-500 cursor-pointer transition-transform transform hover:scale-105 hover:shadow-lg flex-col">
            <img
              className="h-7 mb-2 text-teal-700"
              alt="Donate us"
              src={image.donate_icon}
            />
            <div className="text-sm text-black pt-2">Donate us</div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Home;
