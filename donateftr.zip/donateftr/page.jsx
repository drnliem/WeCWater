'use client';
import React from "react";
import { useRouter } from "next/navigation";
import * as Images from '../imageimport.jsx';
import '../style/donate-us.css';

export const DonateUs = () => {
  const router = useRouter();

  const goToHome = () => {
    router.push("/home");
  };

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
      <header className="bg-blue-100 py-2 px-2 w-full max-w-xl box-border">
        <div className="flex justify-between items-center">
          <div className="flex items-center cursor-pointer px-2 py-2">
            <button>
              <img className="h-7 mr-5 cursor-pointer" alt="Menu" src={Images.menu_icon} />
            </button>
            <img className="h-7 cursor-pointer" alt="User" src={Images.user_icon} />
          </div>
          <div className="flex justify-end">
            <img className="h-20 ml-auto" alt="WeCWater Logo" src={Images.wecwater} />
          </div>
        </div>
      </header>

      {/* Main Donation Section */}
      <div className="donate-us mt-6 w-full max-w-xl" data-model-id="159:249">
        <div className="div">
          <div className="overlap relative">
            <header className="header relative">
              <div className="overlap-group relative">
                <div className="rectangle bg-blue-200 h-24 w-full absolute top-0 left-0 z-0" />

                <img className="wecwater absolute top-4 left-4 h-12" alt="Wecwater" src={Images.wecwater3} />

                <img className="vector absolute top-4 right-16 h-6" alt="Vector" src={Images.vector} />
                <img className="img absolute top-4 right-4 h-6" alt="Vector" src={Images.image} />
              </div>
            </header>

            <div className="text-wrapper text-xl font-bold text-center mt-6 text-gray-800">Support Our Community</div>
          </div>

          <div className="description mt-4 text-center text-gray-700">
            <p className="thank-you px-4">
              Thank you for supporting our community. 100% of your donation will go directly to our non-profit organization.
            </p>
          </div>

          {/* Donation Options */}
          <div className="grid grid-cols-3 gap-4 mt-6 px-4">
            {[10, 20, 50, 100, 200, 500].map((amount, index) => (
              <div key={index} className="element bg-white border-2 border-cyan-500 rounded-lg p-2 text-center cursor-pointer hover:bg-cyan-100">
                <div className="text-lg font-bold text-gray-800">${amount}.00</div>
                <img className="vector-2 mx-auto mt-2 h-4" alt="Select" src={Images[`vector${index + 2}`]} />
              </div>
            ))}
          </div>

          {/* Other Amount */}
          <div className="mt-6 px-4 w-full">
            <div className="name">
              <label className="block text-sm text-gray-700 mb-1">Other Amount</label>
              <input type="text" className="w-full border rounded-md p-2" placeholder="$..." />
            </div>
          </div>

          {/* Message Field */}
          <div className="mt-4 px-4 w-full">
            <label className="block text-sm text-gray-700 mb-1">Message For Us</label>
            <textarea className="w-full border rounded-md p-2" rows="3" placeholder="Write your message here..."></textarea>
          </div>

          {/* Submit Button */}
          <div className="mt-6 px-4 w-full text-center">
            <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-200">
              Submit
            </button>
          </div>
        </div>
      </div>

      {/* Back to Home */}
      <button
        onClick={goToHome}
        className="mt-8 bg-gray-500 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200"
      >
        Go to Home
      </button>
    </div>
  );
};

export default DonateUs;
