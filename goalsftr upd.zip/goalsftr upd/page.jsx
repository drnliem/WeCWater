'use client';
import React from "react";
import { useRouter } from "next/navigation";
import Image from 'next/image';
import * as Images from '../imageimport.jsx'; 
import '../style/goals.css';

export const Goals = () => {
  const router = useRouter();

  const goToHome = () => {
    router.push("/home");
  };

  return (
    <div className="font-sans bg-blue-50 min-h-screen flex flex-col items-center p-5 box-border">
      {/* Header */}
      <header className="bg-blue-100 py-2 px-2 w-full max-w-xl box-border">
        <div className="flex justify-between items-center">
          <div className="flex items-center cursor-pointer px-2 py-2">
            <button>
              <img className="h-7 mr-5 cursor-pointer" alt="Menu" src={Images.menu_icon} />
            </button>
            <img className="h-7 cursor-pointer" alt="User" src={Images.user_icon} />
          </div>
          <div className="flex justify-end">
            <img className="h-20 ml-auto" alt="WeCWater Logo" src={Images.wecwater} />
          </div>
        </div>
      </header>

      {/* Title */}
      <h1 className="text-2xl font-bold text-gray-800 mt-6 mb-4">Our Goals</h1>

      {/* Goals Content */}
      <div className="our-goals text-gray-700 max-w-xl leading-relaxed px-2">
        <p className="mb-4">
          <strong>WeCWater</strong> is a nonprofit social application that aims to mobilize communities in the fight against water pollution. 
          Our mission is to protect and restore our oceans, rivers, and waterways by fostering active citizen participation.
          Through this platform, we work to achieve the following core goals:
        </p>

        <ul className="list-decimal pl-6 space-y-2">
          <li>
            <strong>Promote Environmental Awareness :</strong> Raise awareness about the importance of clean oceans, rivers, and waterways.
          </li>
          <li>
            <strong>Encourage Community Participation :</strong> Inspire individuals and communities to join cleanup efforts.
          </li>
          <li>
            <strong>Facilitate Pollution Reporting : </strong> Enable users to report polluted areas to drive quick action.
          </li>
          <li>
            <strong>Support Sustainable Habits :</strong> Share eco-friendly tips and promote sustainable living.
          </li>
          <li>
            <strong>Build a Global Network of Changemakers:</strong> Connect volunteers and organizations to scale environmental impact.
          </li>
        </ul>
      </div>

      {/* Button */}
      <button 
        onClick={goToHome} 
        className="mt-8 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200"
      >
        Go to Home
      </button>
    </div>
  );
};

export default Goals;
