'use client';
import React from "react";
import { useRouter } from "next/navigation";
import Image from 'next/image';
import * as Images from '../imageimport.jsx'; 
import '../style/goals.css';

const Goals = () => {
  const router = useRouter();

  const goToHome = () => {
    router.push("/home");
  };

  return (
    <div className="goals">
      <div className="container">
        {/* Header */}
        <div className="header">
          <div className="logo-container">
            <div className="logo-bg" />

            {/* logo */}
            <Image 
              className="logo-img" 
              src={Images.wecwater} 
              alt="WeCWater Logo" 
              width={100} 
              height={100} 
            />
          </div>

          <h1 className="title">Our Goals</h1>
        </div>

        {/* Goals Content */}
        <div className="our-goals">
          <p>
            <strong>WeCWater</strong> is a nonprofit social application that aims to mobilize communities in the fight against water pollution. 
            Our mission is to protect and restore our oceans, rivers, and waterways by fostering active citizen participation.  Through this platform, we work to achieve the following core goals:
          </p>

          <ul className="goals-list">
            <li>1. Promote Environmental Awareness : Raise awareness about the importance of clean oceans, rivers, and waterways.</li>
            <li>2. Encourage Community Participation :Inspire individuals and communities to join cleanup efforts.</li>
            <li>3. Facilitate Pollution Reporting :Enable users to report polluted areas to drive quick action.</li>
            <li>4. Support Sustainable Habits : Share eco-friendly tips and promote sustainable living.</li>
            <li>5. Build a Global Network of Changemakers : Connect volunteers and organizations to scale environmental impact.</li>
          </ul>
        </div>

        {/* Button */}
        <button onClick={goToHome} className="go-home-button">
          Go to Home
        </button>
      </div>
    </div>
  );
};

export default Goals;
